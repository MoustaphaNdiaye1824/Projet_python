#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Oct 10 12:28:05 2020

@author: moustaphandiaye
"""


import numpy as np
import matplotlib.pyplot as plt
import exp_training_size

# Tracer les perfomance des algorithmes sur l'ensemble d'apprentissage
npzfile = np.load('outfile.npz')
plt.figure(figsize=(20,15))
plt.semilogy(npzfile['arr_0'][:,0], 
             label="Estimateur moyen sur apprentissage", ls ='--',
             c='blue')
plt.semilogy(npzfile['arr_0'][:,1], 
             label="Estimateur médian sur apprentissage", ls ='--',
             c='green')
plt.semilogy(npzfile['arr_0'][:,2], 
             label="Estimateur majoritaire sur apprentissage", ls ='--',
             c='yellow')
plt.semilogy(npzfile['arr_0'][:,3], 
             label="Estimateur moindre carré sur apprentissage", ls ='--',
             c='red')

# Tracer les perfomance des algorithmes sur l'ensemble de validation
plt.semilogy(npzfile['arr_1'][:,0], 
             label="Estimateur moyen sur validation", c='blue')
plt.semilogy(npzfile['arr_1'][:,1],
             label="Estimateur médian sur validation", c='green')
plt.semilogy(npzfile['arr_1'][:,2],
             label="Estimateur majoritaire sur validation", c='yellow')
plt.semilogy(npzfile['arr_1'][:,3],
             label="Estimateur moindre carré sur validation", c='red')
plt.xlabel("Ensemble d'apprentissage")
plt.ylabel("Erreur")
plt.legend(loc="upper right")
plt.title("Performance des algorithmes")
plt.savefig("performance.png")
plt.show()

# Tracer les temps de calcul des algorithmes
npzfile_time = np.load('outfile_time.npz')
plt.semilogy(npzfile_time['arr_0'][:,0], 
             label="Temps de calcul de l'estimateur moyen", c='blue')
plt.semilogy(npzfile_time['arr_0'][:,1],
             label="Temps de calcul de l'estimateur médian ", c='green')
plt.semilogy(npzfile_time['arr_0'][:,2],
             label="Temps de calcul de l'estimateur majoritaire ", c='yellow')
plt.semilogy(npzfile_time['arr_0'][:,3],
             label="Temps de calcul de l'estimateur moindre carré ", c='red')
plt.xlabel("Ensemble d'apprentissage")
plt.ylabel("temps de calcul")
plt.legend(loc="upper left")
plt.title("temps de calcul des algorithmes sur l'ensemble d'apprentissage")
plt.savefig("temps_calcul.png")
plt.show()