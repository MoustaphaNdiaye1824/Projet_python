#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct  4 23:00:02 2020

@author: moustaphandiaye
"""


import numpy as np
import matplotlib.pyplot as plt
from data_utils import load_data, split_data, randomize_data
from linear_regression import LinearRegression, LinearRegressionMean
from linear_regression import LinearRegression, LinearRegressionMajority
from linear_regression import LinearRegression, LinearRegressionMedian
from linear_regression import LinearRegression, LinearRegressionLeastSquares
from tempfile import TemporaryFile
import time

# exercice 5 : Performance d'un estimateur constant

# Charger les données étiquetés
YearPredictionMSD_100 = load_data('data/YearPredictionMSD_100.npz')
X = YearPredictionMSD_100[0]
y = YearPredictionMSD_100[1]

# Créer un échantillon d'apprentissage et de validation
Xtrain, ytrain, Xvalid, yvalid = split_data(X, y, 2/3)
Strain = np.zeros((Xtrain.shape[0], Xtrain.shape[0]+1))
Strain[:,:90] = Xtrain 
Strain[:,90] = ytrain

# Construire l'ensemble N
N = np.array([2**i for i in  range(5,12)])


# Conxtuire et initialiser les vecteurs Train_error et valid_error
train_error = np.zeros(N.size)
valid_error = np.zeros(N.size)

# Construire un ensemble d'apprentisssage pour chaque élement de N avec l'estimateur constant
# moyen
for i in N:
    Xtrain = X[:i,]
    ytrain = y[:i]
    model = LinearRegressionMean()
    model.fit(Xtrain, ytrain)
    pred = model.predict(Xtrain)
    error =  (1/i) * np.sum((ytrain - pred)**2)
    train_error[np.where(i==N)] = error
    pred_valid = model.predict(Xvalid)
    error_valid =  (1/yvalid.size) * np.sum((yvalid - pred_valid)**2)
    valid_error[np.where(i==N)] = error_valid
print("L'erreur d'apprentissage est :", train_error)
print("------------------------------------------------------------")
print("L'erreur de validation est :", valid_error)

# Sauvegarder train_error, valid_error et N dans un fichier
outfile = TemporaryFile()
np.savez(outfile, train_error, valid_error, N)
outfile.seek(0)
npzfile = np.load(outfile)
npzfile.files

# Exercice 6 : Performance des autres estimateurs constants

# Conxtuire et initialiser les matrices Train_error et valid_error
train_error = np.zeros((N.size, 3))
valid_error = np.zeros((N.size, 3))

# Construire des ensembles d'apprentisssage pour chaque élement de N avec tous les estimateurs
# constants
for i in N:
    Xtrain = X[:i,]
    ytrain = y[:i]
    model = LinearRegressionMean()
    model.fit(Xtrain, ytrain)
    pred = model.predict(Xtrain)
    error = (1/i) * np.sum((ytrain - pred)**2)
    train_error[np.where(i==N), 0] = error
    pred_valid = model.predict(Xvalid)
    error_valid = (1/yvalid.size) * np.sum((yvalid - pred_valid)**2)
    valid_error[np.where(i==N), 0] = error_valid
    
    model2 = LinearRegressionMedian()
    model2.fit(Xtrain, ytrain)
    pred2 = model2.predict(Xtrain)
    error2 = (1/i) * np.sum((ytrain - pred2)**2)
    train_error[np.where(i==N), 1] = error2
    pred_valid2 = model2.predict(Xvalid)
    error_valid2 = (1/yvalid.size) * np.sum((yvalid - pred_valid2)**2)
    valid_error[np.where(i==N), 1] = error_valid
    
    model3 = LinearRegressionMajority()
    model3.fit(Xtrain, ytrain)
    pred3 = model3.predict(Xtrain)
    error3 = np.sqrt((1/i) * np.sum((ytrain - pred3)**2))
    train_error[np.where(i==N), 2] = error3
    pred_valid3 = model3.predict(Xvalid)
    error_valid3 = (1/yvalid.size) * np.sum((yvalid - pred_valid3)**2)
    valid_error[np.where(i==N), 2] = error_valid
    
print("L'erreur d'apprentissage est :\n", train_error)
print("------------------------------------------------------------")
print("L'erreur de validation est :\n", valid_error)

print("------------------------------------------------------------")

# Exercice 7 : Performance de l’estimateur linéaire des moindres carrés

# Conxtuire et initialiser les vecteurs Train_error_mc et valid_error_mc pour le critère des
# moindre carré
train_error_mc = np.zeros(N.size)
valid_error_mc = np.zeros(N.size)

# Construire un ensemble d'apprentisssage pour chaque élement de N
for i in N:
    Xtrain = X[:i,]
    ytrain = y[:i]
    model_mc = LinearRegressionLeastSquares()
    model_mc.fit(Xtrain, ytrain)
    pred_mc = model_mc.predict(Xtrain)
    error_mc = (1/i) * np.sum((ytrain - pred_mc)**2)
    train_error_mc[np.where(i==N)] = error_mc
    pred_valid_mc = model_mc.predict(Xvalid)
    error_valid_mc = (1/yvalid.size) * np.sum((yvalid - pred_valid_mc)**2)
    valid_error_mc[np.where(i==N)] = error_valid_mc

# Rassembler les vecteurs d'erreur train_error et valid_error de toutes les stratégie
# dans deux matrices    
train_error = np.hstack((train_error, train_error_mc.reshape(7,1)))
valid_error = np.hstack((valid_error, valid_error_mc.reshape(7,1)))
print("L'erreur d'apprentissage est : \n", np.around(train_error, decimals=2))
print("------------------------------------------------------------")
print("L'erreur de validation est : \n", np.around(valid_error, decimals=2))

# Sauvegarder train_error, valid_error et N dans un fichier

np.savez('outfile', train_error, valid_error, N)
npzfile = np.load('outfile.npz')
npzfile.files


# Exercice 8: Affichage et analyse des résultats (Voir plot_exp_training.py)

# Exercice 9 Mesure des temps de calcul

# initialisation de la matrice du temps de calcul
learning_time = np.zeros((N.size,4))

# Calculer le temps d'execution da chaque stratégie pour l'ensemble d'apprentissage
for i in N:
    Xtrain = X[:i,]
    ytrain = y[:i]
    tps1 = time.clock()  
    model = LinearRegressionMean()
    model.fit(Xtrain, ytrain)
    pred = model.predict(Xtrain)
    error = (1/i) * np.sum((ytrain - pred)**2)
    train_error[np.where(i==N), 0] = error
    tps2 = time.clock()  
    temps = tps2 - tps1
    learning_time[np.where(N==i), 0] = temps
    
    tps1 = time.clock()  
    model2 = LinearRegressionMedian()
    model2.fit(Xtrain, ytrain)
    pred2 = model2.predict(Xtrain)
    error2 = (1/i) * np.sum((ytrain - pred2)**2)
    train_error[np.where(i==N), 1] = error2
    tps2 = time.clock()  
    temps = tps2 - tps1
    learning_time[np.where(N==i), 1] = temps
    
    tps1 = time.clock()  
    model3 = LinearRegressionMajority()
    model3.fit(Xtrain, ytrain)
    pred3 = model3.predict(Xtrain)
    error3 = (1/i) * np.sum((ytrain - pred3)**2)
    train_error[np.where(i==N), 2] = error3
    tps2 = time.clock()  
    temps = tps2 - tps1
    learning_time[np.where(N==i), 2] = temps
    
    tps1 = time.clock()  
    train_error_mc = np.zeros(N.size)
    model_mc = LinearRegressionLeastSquares()
    model_mc.fit(Xtrain, ytrain)
    pred_mc = model_mc.predict(Xtrain)
    error_mc = (1/i) * np.sum((ytrain - pred_mc)**2)
    train_error[np.where(i==N), 3] = error_mc
    tps2 = time.clock()  
    temps = tps2 - tps1
    learning_time[np.where(N==i), 3] = temps
    
# Sauvegarder la matirce du temps de calcul dans un fichier npz  
np.savez('outfile_time', learning_time)
npzfile_time = np.load('outfile_time.npz')
npzfile_time.files

