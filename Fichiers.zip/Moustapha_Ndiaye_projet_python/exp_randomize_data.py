#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 16:03:05 2017

@author: Valentin Emiya, AMU & CNRS LIF
"""
import numpy as np
from data_utils import randomize_data

""" Small programme to run randomize_data """
n_examples = 5
data_dim = 4
# TODO À compléter
X = np.array(range(20)).reshape(5, 4)
y = np.array([1, -4,-8, -12, -16])
print("La matrice X avant permutation :\n", X)
print("Le vecteur y avant permutation :", y)
print("-----------------------------------------")
Xr, yr = randomize_data(X, y)
print("La matrice Xr après permutation :\n", Xr)
print("Le vecteur yr après permutation :", yr)

