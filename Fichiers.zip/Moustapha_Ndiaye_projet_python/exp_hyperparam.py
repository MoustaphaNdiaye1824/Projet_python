#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 26 20:47:47 2020

@author: moustaphandiaye
"""

from data_utils import load_data, split_data, randomize_data
from linear_regression import LinearRegressionRidge, LinearRegressionMp, LinearRegressionOmp
import numpy as np
import matplotlib.pyplot as plt

# Importation des données
#YearPredictionMSD_100 = load_data('data/YearPredictionMSD_100.npz')
#X_labeled, y_labeled, X_unlabeled = YearPredictionMSD_100
X_labeled, y_labeled, X_unlabeled = load_data('data/YearPredictionMSD_100.npz')

# Permutation des données
Xr, yr = randomize_data(X_labeled, y_labeled)

# Echantillon d'apprentissage et de test
X_train = Xr[:500,:]
y_train = yr[:500]
X_valid = Xr[500:,:]
y_valid = yr[500:]

# Initialisation des hyperparamètres
lambda_ridge = np.arange(0, 9, 0.01)
k_max = np.arange(1, 100, 1)

# Application des algorithmes

# Initialalisation des vecteurs d'erreurs
train_error_ridge = []
valid_error_ridge = []
train_error_MP = []
valid_error_MP  = []
train_error_OMP = []
valid_error_OMP = []


# Algorithme de Ridge
for lamb in lambda_ridge:
    # On fait appel à la classe LinearRegressionRidge
    model = LinearRegressionRidge(lamb)
    # Phase d'apprentissage du modèle
    model.fit(X_train, y_train)
    # Prédiction du modèle
    pred = model.predict(X_train)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble d'apprentissage
    error =  np.sqrt((1/y_train.size) * np.sum((y_train - pred)**2))
    # Ajout de l'erreur d'apprentissage dans le vecteur des erreurs quadratique moyenne
    train_error_ridge.append(error)
    # Phase de validation du modèle
    pred_valid = model.predict(X_valid)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
    error_valid =  np.sqrt((1/y_valid.size) * np.sum((y_valid - pred_valid)**2))
    # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
    valid_error_ridge.append(error_valid)
    
# Visualisation des erreurs d'apprentissage et de validation
plt.figure(figsize = (20,15))
plt.plot(lambda_ridge, train_error_ridge,
             label = "Erreur d'apprentissage", c = 'blue', linewidth=5)
plt.plot(lambda_ridge, valid_error_ridge,
             label = "Erreur de validation", c = 'red', linewidth=5)
plt.xlabel("Lambda Ridge", fontsize=50)
plt.ylabel("Erreur quadratique moyenne", fontsize=50)
plt.legend(loc = "lower right", fontsize=50)
plt.title("Performance de l'algorithme de Ridge", fontsize=30)
plt.savefig("error_ridge.png")
plt.show()

# Choix de la valeur optimale pour lambda_ridge
indice = np.where(valid_error_ridge == min(valid_error_ridge))
lambda_optimal = lambda_ridge[indice[0]]
print("L'hyperparamètre optimale pour l'algorithme de Ridge est :", lambda_optimal)
print("------------------------------------------------------------")

# Algorithmes MP
for k in k_max:
    # On fait appel à la classe LinearRegressionMp
    model = LinearRegressionMp(k)
     # Phase d'apprentissage du modèle
    model.fit(X_train, y_train)
    # Prédiction du modèle
    pred = model.predict(X_train)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble d'apprentissage
    error =  np.sqrt((1/y_train.size) * np.sum((y_train - pred)**2))
    # Ajout de l'erreur d'apprentissage dans le vecteur des erreurs quadratique moyenne
    train_error_MP.append(error)
    # Phase de validation du modèle
    pred_valid = model.predict(X_valid)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
    error_valid =  np.sqrt((1/y_valid.size) * np.sum((y_valid - pred_valid)**2))
    # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
    valid_error_MP.append(error_valid)
    
# Visualisation des erreurs d'apprentissage et de validation    
plt.figure(figsize = (20,15))
plt.plot(train_error_MP,
             label = "Erreur d'apprentissage", c = 'blue', linewidth=5)
plt.plot(valid_error_MP,
             label = "Erreur de validation", c = 'red', linewidth=5)
plt.xlabel("k_max", fontsize=50)
plt.ylabel("Erreur quadratique moyenne", fontsize=50)
plt.legend(loc = "upper right", fontsize=50)
plt.title("Performance de l'algorithme MP", fontsize=30)
plt.savefig("error_MP.png")
plt.show()

# Choix de la valeur optimale pour k_max 
indice = np.where(valid_error_MP == min(valid_error_MP))
k_optimal_MP = k_max[indice[0]]
print("L'hyperparamètre optimale pour l'algorithme MP est :", k_optimal_MP)
print("------------------------------------------------------------------")

# Algorithmes OMP
for k in k_max:
    # On fait appel à la classe LinearRegressionOmp
    model = LinearRegressionOmp(k)
    # Phase d'apprentissage du modèle
    model.fit(X_train, y_train)
    # Prédiction du modèle
    pred = model.predict(X_train)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble d'apprentissage
    error =  np.sqrt((1/y_train.size) * np.sum((y_train - pred)**2))
    # Ajout de l'erreur d'apprentissage dans le vecteur des erreurs quadratique moyenne
    train_error_OMP.append(error)
    # Phase de validation du modèle
    pred_valid = model.predict(X_valid)
    # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
    error_valid =  np.sqrt((1/y_valid.size) * np.sum((y_valid - pred_valid)**2))
    # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
    valid_error_OMP.append(error_valid)
    
# Visualisation des erreurs d'apprentissage et de validation      
plt.figure(figsize = (20,15))
plt.plot(train_error_OMP,
             label = "Erreur d'apprentissage", c = 'blue', linewidth=5)
plt.plot(valid_error_OMP,
             label = "Erreur de validation", c = 'red', linewidth=5)
plt.xlabel("k_max", fontsize=50)
plt.ylabel("Erreur quadratique moyenne", fontsize=50)
plt.legend(loc = "upper right", fontsize=50)
plt.title("Performance de l'algorithme OMP", fontsize=30)
plt.savefig("error_OMP.png")
plt.show()

# Choix de la valeur optimale pour k_max 
indice = np.where(valid_error_OMP == min(valid_error_OMP))
k_optimal_OMP = k_max[indice[0]]
print("L'hyperparamètre optimale pour l'algorithme OMP est :", k_optimal_OMP)



