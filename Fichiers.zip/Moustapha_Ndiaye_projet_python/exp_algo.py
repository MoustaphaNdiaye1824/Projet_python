#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  7 18:27:50 2020

@author: moustaphandiaye
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 13:30:59 2020

@author: moustaphandiaye
"""

from data_utils import load_data, split_data, randomize_data
from linear_regression import LinearRegressionRidge, LinearRegressionMp, LinearRegressionOmp
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

from linear_regression import LinearRegression, LinearRegressionMean
from linear_regression import LinearRegression, LinearRegressionMajority
from linear_regression import LinearRegression, LinearRegressionMedian
from linear_regression import LinearRegression, LinearRegressionLeastSquares

#import exp_training_size



# Exercice 1 : Apprentissage des hyperparamètres

# Algorithme de Ridge
#valid_error_ridge = []
#test_error_ridge = []
#lambda_ridge = np.linspace(0.01, 1, 20)

def learn_all_with_RIDGE(X, y):
    """
    Tests multiple hyperparameter values and returns the hyperparameter
     with the minimum validation error.

    Parameters
    ----------
    X : np.ndarray [n, d]
        Array of n feature vectors with size d
    y : np.ndarray [n]
        Vector of n labels related to the n feature vectors
        
    Returns
    -------
    model : objet of LinearRegression
    
    """
    
    # Initialisation des vecteurs d'erreur
    train_error_ridge = []
    valid_error_ridge = []
    # Initialisation de l'hyperparamètre
    lambda_ridge = np.linspace(0.01, 1, 20)
    
    # Echantillonnage
    X_train, y_train, X_test, y_test = split_data(X, y, 2/3)
    X_train_2, y_train_2, X_valid, y_valid = split_data(X_train, y_train, 2/3)
    for lamb in lambda_ridge:
        # On fait appel à la classe LinearRegressionRidge
        model = LinearRegressionRidge(lamb)
        # Phase d'apprentissage du modèle
        model.fit(X_train_2, y_train_2)
        
        # Prédiction du modèle
        pred = model.predict(X_train_2)
        # Calcul de l'erreur quadratique moyenne sur l'ensemble d'apprentissage
        error =  mean_squared_error(y_train_2, pred)
        # Ajout de l'erreur d'apprentissage dans le vecteur des erreurs quadratique moyenne
        train_error_ridge.append(error)
        
        # Phase de validation du modèle
        pred_valid = model.predict(X_valid)
        # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
        error_valid =  mean_squared_error(y_valid, pred_valid)
        # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
        valid_error_ridge.append(error_valid)
        
    # Choix de la valeur optimale pour lambda_ridge
    indice = np.argmin(valid_error_ridge)
    lambda_optimal = lambda_ridge[indice]
    erreur_optimal = np.min(valid_error_ridge)
    
    
    # Ré-entraintrement du modèle avec le paramètre optimal
    # On fait appel à la classe LinearRegressionRidge
    model = LinearRegressionRidge(lambda_optimal)
    model.fit(X, y)

    return model
    
    
# Algorithme de MP

def learn_all_with_MP(X, y):
    """
    Tests multiple hyperparameter values and returns the hyperparameter
     with the minimum validation error.

    Parameters
    ----------
    X : np.ndarray [n, d]
        Array of n feature vectors with size d
    y : np.ndarray [n]
        Vector of n labels related to the n feature vectors
        
    Returns
    -------
    model : objet of LinearRegression
    """
    
    # Initialisation des vecteurs d'erreur
    train_error_mp = []
    valid_error_mp = []
    # Initialisation de l'hyperparamètre
    k_max = np.arange(1, 100, 1)
    
    # Echantillonnage
    X_train, y_train, X_test, y_test = split_data(X, y, 2/3)
    X_train_2, y_train_2, X_valid, y_valid = split_data(X_train, y_train, 2/3)
    for k in k_max:
        # On fait appel à la classe LinearRegressionMP
        model = LinearRegressionMp(k)
        # Phase d'apprentissage du modèle
        model.fit(X_train_2, y_train_2)
        
        # Prédiction du modèle
        pred = model.predict(X_train_2)
        # Calcul de l'erreur quadratique moyenne sur l'ensemble d'apprentissage
        error =  mean_squared_error(y_train_2, pred)
        # Ajout de l'erreur d'apprentissage dans le vecteur des erreurs quadratique moyenne
        train_error_mp.append(error)
        
        
        # Phase de validation du modèle
        pred_valid = model.predict(X_valid)
        # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
        error_valid =  mean_squared_error(y_valid, pred_valid)
        # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
        valid_error_mp.append(error_valid)
        
    # Choix de la valeur optimale pour k_optimal
    indice = np.argmin(valid_error_mp)
    k_optimal = k_max[indice]
    erreur_optimal = np.min(valid_error_mp)
    

    
    # Ré-entraintrement du modèle avec le paramètre optimal
    # On fait appel à la classe LinearRegressionMP
    model = LinearRegressionMp(k_optimal)
    model.fit(X, y)
    
    return model
    

# Algorithme de OMP

def learn_all_with_OMP(X, y):
    """
    Tests multiple hyperparameter values and returns the hyperparameter
     with the minimum validation error.

    Parameters
    ----------
    X : np.ndarray [n, d]
        Array of n feature vectors with size d
    y : np.ndarray [n]
        Vector of n labels related to the n feature vectors
        
    Returns
    -------
    model : objet of LinearRegression
    """
    
    # Initialisation des vecteurs d'erreur
    train_error_omp = []
    valid_error_omp = []
    # Initialisation de l'hyperparamètre
    k_max = np.arange(1, 100, 1)
    
    # Echantillonnage
    X_train, y_train, X_test, y_test = split_data(X, y, 2/3)
    X_train_2, y_train_2, X_valid, y_valid = split_data(X_train, y_train, 2/3)
    for k in k_max:
        # On fait appel à la classe LinearRegressionMP
        model = LinearRegressionOmp(k)
        # Phase d'apprentissage du modèle
        model.fit(X_train_2, y_train_2)
        # Phase de validation du modèle
        pred_valid = model.predict(X_valid)
        # Calcul de l'erreur quadratique moyenne sur l'ensemble de validation
        error_valid =  mean_squared_error(y_valid, pred_valid)
        # Ajout de l'erreur de validation dans le vecteur des erreurs quadratique moyenne
        valid_error_omp.append(error_valid)
        
    # Choix de la valeur optimale pour k_optimal
    indice = np.argmin(valid_error_omp)
    k_optimal = k_max[indice]
    erreur_optimal = np.min(valid_error_omp)
    
    
    # Ré-entraintrement du modèle avec le paramètre optimal
    # On fait appel à la classe LinearRegressionMP
    model = LinearRegressionOmp(k_optimal)
    model.fit(X, y)
    
    return model
   
    
# Exercice 2 : Sélection du meilleur algorithme

# Importation des données
X_labeled, y_labeled, X_unlabeled = load_data('data/YearPredictionMSD_100.npz')

# Importation du fichier contenant les performances des algorithmes consatants
npzfile = np.load('outfile.npz')
sizes = npzfile['arr_2']

# Construire l'ensemble N
N = np.array([2**i for i in  range(5,12)])
# Constuire et initialiser les vecteurs de validaion et les hyperparmètres
test_error_ridge = []
lambda_optimal_ridge = []

test_error_mp = []
k_optimal_mp = []

test_error_omp = []
k_optimal_omp = []

for i in N:
    # Construire l'ensemble S_train
    X_train = X_labeled[:i,]
    y_train = y_labeled[:i]
    # Construire l'ensemble S_valid
    X_test = X_labeled[i:,]
    y_test = y_labeled[i:]

    # Appel de l'objet learn_all_with_RIDGE
    model = learn_all_with_RIDGE(X_train, y_train)
    # Faire les prédictions à partir de ce modèle sur l'ensemble de validation 2
    pred_ridge = model.predict(X_test)
    # Mise à jour du vecteur contenant les erreurs de prédictions
    test_error_ridge.append(mean_squared_error(y_test, pred_ridge))
    
    # Appel de l'objet learn_all_with_MP
    model = learn_all_with_MP(X_train, y_train)
    # Faire les prédictions à partir de ce modèle sur l'ensemble de validation 2
    pred_mp = model.predict(X_test)
    # Mise à jour du vecteur contenant les erreurs de prédictions
    test_error_mp.append(mean_squared_error(y_test, pred_mp))
    
    # Appel de l'objet learn_all_with_OMP
    model = learn_all_with_OMP(X_train, y_train)
    # Faire les prédictions à partir de ce modèle sur l'ensemble de validation 2
    pred_omp = model.predict(X_test)
    # Mise à jour du vecteur contenant les erreurs de prédictions
    test_error_omp.append(mean_squared_error(y_test, pred_omp))

    
# Visualisation des performances de prédictions des différents algorithmes 
# sur l'ensemble de validation 2
plt.figure(figsize=(20, 15))
plt.semilogy(sizes, test_error_ridge, label = "Ridge validation ", 
             color = 'blue', linewidth = 5)
plt.semilogy(sizes, test_error_mp, label = "MP validation",
             color = 'red', linewidth = 5)
plt.semilogy(sizes, test_error_omp, label = "OMP validation", 
             color = 'aqua', linewidth = 5)
plt.semilogy(sizes, npzfile['arr_1'][:,0], label = "Estimateur moyen",
              c = 'darkorange', linewidth = 5)
plt.semilogy(sizes, npzfile['arr_1'][:,1], label = "Estimateur médian",
              c = 'darkolivegreen', linewidth = 5)
plt.semilogy(sizes, npzfile['arr_1'][:,2], label = "Estimateur majoritaire",
              c = 'indigo', linewidth = 5)
plt.semilogy(sizes, npzfile['arr_1'][:,3], label = "Estimateur moindre carré",
              c = 'purple', linewidth = 5)

plt.legend(loc = 'upper right')
plt.title("Performance des algorithmes sur l'ensemble de validation", fontsize = 20, 
          loc = 'center')
plt.xlabel("Ensemble d'apprentissage", fontsize = 30)
plt.ylabel('Erreur', fontsize = 30)
plt.savefig('algo_performance.png')
plt.show()
    

# Exercice 3 : Soumission de votre prédiction sur les exemples non-étiquetés

def learn_best_predictor_and_predict_test_data(X, y, X_un):
    """
    Tests the best predictor algorithme and predict the unlabeled data.

    Parameters
    ----------
     X_labeled : np.ndarray [n, d]
        Array of n feature vectors with size d
     y_labeled : np.ndarray [n]
        Vector of n labels related to the n feature vectors
     X_unlabeled : np.ndarray [n', d']
        Array of n' feature vectors with size d'
        
    Returns
    -------
    y_test : np.ndarray [n']
        Vector of n' predictions
    """
    # Définir un ensemble d’apprentissage de taille 500
    X_train = X[:500,]
    y_train = y[:500]
    # Définir un ensemble de validation sur le reste des données
    X_valid = X[500:,]
    y_valid = y[500:]
    
    # Appel de l'objet learn_all_with_RIDGE
    model = learn_all_with_RIDGE(X_train, y_train)
    # Faire les prédictions à partir de ce modèle sur l'ensemble de validation 2
    pred = model.predict(X_valid)
    # Calcul et affichage de l'erreur de prédiction
    test_error_ridge = mean_squared_error(y_valid, pred)
    print("L'erreur de prediction est :", test_error_ridge)
    
    # En fin faire la prédiction des date de sortie de chansons des données non-étiquetées 
    y_test = model.predict(X_un)
    
    return y_test

# Appel de la fonction du meilleur prédicteur et stocker les valeurs prédites
y_test = learn_best_predictor_and_predict_test_data(X_labeled, y_labeled, X_unlabeled)
np.savez("test_prediction_results.npy", y_test)
    
plt.plot(y_test)
plt.xlabel("Observation", fontsize = 20)
plt.ylabel("Prédiction", fontsize = 20)
plt.title("Graphique des prédictions", fontsize = 20)
plt.savefig('predictions.png')
plt.show()   
    
    
    